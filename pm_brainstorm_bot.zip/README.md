
# PM Brainstorm Bot 🤖💡

An AI-powered chatbot that helps project managers brainstorm new ideas and explore project challenges.

## 🔧 Tech Stack
- Python + Streamlit
- OpenAI GPT-3.5-turbo
- Hosted on Hugging Face Spaces

## ✨ Features
- Generates 3 creative ideas for your project prompt
- Suggests benefits
- Asks guiding follow-up questions

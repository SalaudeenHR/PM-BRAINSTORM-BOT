
import streamlit as st
import openai

# 🔑 Set your OpenAI API key
openai.api_key = st.secrets.get("OPENAI_API_KEY")

# 🧠 System prompt to guide the chatbot
SYSTEM_PROMPT = """
You are an expert project management ideation assistant.
When a user asks for ideas, generate 3 distinct, creative, and practical project ideas for the given topic.
For each idea, include a brief description and 2 unique benefits.
Conclude with a guiding follow-up question.
"""

# 🎨 Streamlit UI
st.set_page_config(page_title="PM Brainstorm Bot", page_icon="🤖")
st.title("🤖 PM Brainstorm Bot")
st.markdown("Generate project ideas and explore risks creatively with AI!")

# 🧾 Initialize chat history
if "messages" not in st.session_state:
    st.session_state.messages = [{"role": "system", "content": SYSTEM_PROMPT}]

# 💬 Display previous messages
for msg in st.session_state.messages[1:]:
    st.chat_message(msg["role"]).write(msg["content"])

# ✍️ User input
prompt = st.chat_input("Type your project idea or challenge here...")

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.chat_message("user").write(prompt)

    with st.spinner("Thinking..."):
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=st.session_state.messages,
            temperature=0.7,
        )
        reply = response.choices[0].message["content"]
        st.session_state.messages.append({"role": "assistant", "content": reply})
        st.chat_message("assistant").write(reply)
